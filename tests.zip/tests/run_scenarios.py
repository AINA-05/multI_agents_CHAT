from agents.coordinator import Coordinator
from agents.research_agent import ResearchAgent
from agents.analysis_agent import AnalysisAgent
from agents.memory_agent import MemoryAgent

queries = [
    "What are the main types of neural networks?",
    "Research transformer architectures, analyze their computational efficiency, and summarize key trade-offs.",
    "What did we discuss about neural networks earlier?",
    "Find recent papers on reinforcement learning, analyze their methodologies, and identify common challenges.",
    "Compare two machine-learning approaches and recommend which is better for our use case."
]

coordinator = Coordinator(
    ResearchAgent(),
    AnalysisAgent(),
    MemoryAgent()
)

for q in queries:
    print("\nUser:", q)
    print("System:", coordinator.handle_query(q))
