class AnalysisAgent:
    def analyze(self, data):
        if not data:
            return {
                "analysis": "Not enough data to analyze.",
                "confidence": 0.2
            }

        analysis_text = (
            "After comparison, the following observations were made:\n"
            + ", ".join(data)
        )

        return {
            "analysis": analysis_text,
            "confidence": 0.9
        }
