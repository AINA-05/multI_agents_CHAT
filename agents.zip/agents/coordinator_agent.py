from memory.schema import MemoryRecord

class Coordinator:
    def __init__(self, research_agent, analysis_agent, memory_agent):
        self.research_agent = research_agent
        self.analysis_agent = analysis_agent
        self.memory_agent = memory_agent

    def analyze_complexity(self, query: str):
        keywords = [
            "analyze", "analyse", "compare", "summarize", 
            "trade-off", "better", "best", "worst", 
            "difference", "vs", "versus"
        ]
        return any(word in query.lower() for word in keywords)

    def handle_query(self, query: str):
        print(f"\n[Coordinator] User Query: {query}")

        # Step 1: Check memory (adaptive behavior)
        memory_results = self.memory_agent.search_by_vector(query)
        if memory_results and memory_results[0][1] > 0.75:
            print("[Coordinator] Retrieved answer from memory.")
            return memory_results[0][0]

        # Step 2: Decide plan
        is_complex = self.analyze_complexity(query)
        print(f"[Coordinator] Complexity Detected: {is_complex} (Routing to Analysis Agent if True)")

        # Step 3: Research
        print(f"[Coordinator] Delegating to ResearchAgent...")
        research_result = self.research_agent.research(query)
        print(f"[ResearchAgent] Found: {research_result['topic']} (Confidence: {research_result['confidence']})")
        # print("[ResearchAgent] Output:", research_result)  # Reduced verbosity for clarity

        if not research_result["data"]:
             return "I'm sorry, I couldn't find any information on that topic in my knowledge base. Try asking about 'neural networks', 'transformers', or 'machine learning'."

        final_output = research_result["data"]

        # Step 4: Analysis if required
        if is_complex:
            analysis_result = self.analysis_agent.analyze(final_output)
            print("[AnalysisAgent] Output:", analysis_result)
            final_output = analysis_result["analysis"]
            confidence = analysis_result["confidence"]
        else:
            confidence = research_result["confidence"]

        # Step 5: Store in memory
        record = MemoryRecord(
            content=str(final_output),
            topic=research_result["topic"],
            source="MockKnowledgeBase",
            agent="Coordinator",
            confidence=confidence
        )

        self.memory_agent.store_record(record)

        return final_output
