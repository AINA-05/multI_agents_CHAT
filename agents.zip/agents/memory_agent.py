from memory.vector_store import VectorStore
import json
import os
from dataclasses import asdict
from memory.schema import MemoryRecord

MEMORY_FILE = "memory_data.json"

class MemoryAgent:
    def __init__(self):
        self.records = []
        self.vector_store = VectorStore()
        self.load_memory()

    def store_record(self, record):
        self.records.append(record)
        self.vector_store.add_text(record.content)
        self.save_memory()

    def search_by_vector(self, query):
        return self.vector_store.similarity_search(query)

    def search_by_topic(self, topic):
        return [
            record for record in self.records
            if record.topic.lower() == topic.lower()
        ]

    def get_all_memory(self):
        return self.records

    def save_memory(self):
        data = [asdict(record) for record in self.records]
        with open(MEMORY_FILE, "w") as f:
            json.dump(data, f, indent=4)

    def load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r") as f:
                    data = json.load(f)
                    for item in data:
                        # Reconstruct MemoryRecord objects
                        record = MemoryRecord(**item)
                        self.records.append(record)
                        self.vector_store.add_text(record.content)
                print(f"[MemoryAgent] Loaded {len(self.records)} records from storage.")
            except Exception as e:
                print(f"[MemoryAgent] Error loading memory: {e}")

