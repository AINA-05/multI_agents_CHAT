


class ResearchAgent:
    def __init__(self):
        # Mock knowledge base (simulated web search)
        self.knowledge_base = {
            "neural network": [
                "Feedforward Neural Networks",
                "Convolutional Neural Networks (CNNs)",
                "Recurrent Neural Networks (RNNs)",
                "Transformers"
            ],
            "transformer": [
                "Self-attention mechanism",
                "Parallel sequence processing",
                "High computational and memory cost"
            ],
            "reinforcement learning": [
                "Q-learning",
                "Policy Gradients",
                "Actor-Critic methods"
            ],
            "machine learning": [
                "Supervised Learning",
                "Unsupervised Learning",
                "Reinforcement Learning"
            ],
            "optimizer": [
                "Gradient Descent",
                "Stochastic Gradient Descent",
                "Adam",
                "RMSProp"
            ]
        }

    def research(self, query: str):
        query_lower = query.lower()
        for topic, data in self.knowledge_base.items():
            # Check topic match
            if topic in query_lower or query_lower in topic:
                return {
                    "topic": topic,
                    "data": data,
                    "confidence": 0.85
                }
            
            # Check content match (subtopics)
            # We split query into words to find acronyms or keywords like "CNNs" inside "Convolutional Neural Networks (CNNs)"
            query_words = [w for w in query_lower.split() if len(w) > 3]
            for item in data:
                # Check if any significant word from query is inside this item
                for word in query_words:
                    if word in item.lower():
                        return {
                            "topic": topic,
                            "data": data,
                            "confidence": 0.85
                        }

        return {
            "topic": "unknown",
            "data": [],
            "confidence": 0.3
        }
