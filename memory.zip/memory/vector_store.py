from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class VectorStore:
    def __init__(self):
        self.texts = []
        self.vectorizer = TfidfVectorizer()
        self.vectors = None

    def add_text(self, text: str):
        if not text or not text.strip():
            return
        self.texts.append(text)
        try:
            self.vectors = self.vectorizer.fit_transform(self.texts)
        except ValueError:
            # Handle case where vocabulary is empty or texts are all stop words
            self.vectors = None

    def similarity_search(self, query: str, top_k=1):
        if not self.texts or self.vectors is None:
            return []

        query_vec = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vec, self.vectors)[0]

        ranked = sorted(
            list(enumerate(similarities)),
            key=lambda x: x[1],
            reverse=True
        )

        results = []
        for idx, score in ranked[:top_k]:
            results.append((self.texts[idx], score))

        return results
