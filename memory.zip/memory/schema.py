from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class MemoryRecord:
    content: str
    topic: str
    source: str
    agent: str
    confidence: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
